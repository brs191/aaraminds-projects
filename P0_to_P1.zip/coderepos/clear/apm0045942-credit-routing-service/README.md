# apm0045942-credit-routing-service

[![Java CI with Maven](https://github.com/ATT-DP1/apm0045942-credit-routing-service/actions/workflows/maven.yml/badge.svg)](https://github.com/ATT-DP1/apm0045942-credit-routing-service/actions/workflows/maven.yml)

## Overview

The **Credit Routing Service** is a Spring Boot 3.3.9 microservice that handles credit routing and orchestrating credit check requests based on configurable business rules managed by credit finance team. It provides REST APIs for credit checks, supports multi-product credit evaluation, and integrates with MongoDB for persistent storage and Kafka for asynchronous event streaming.

### Key Features

- **Custom DSL-based Rules Processing**: Flexible credit evaluation rules engine
- **Multi-Product Credit Checks**: Support for simultaneous credit evaluation across multiple products
- **Identity Verification**: Customer identity validation and verification workflows
- **Policy Enforcement**: Credit policy management and dynamic policy application
- **MongoDB Integration**: Persistent storage of routing rules and credit check results
- **Kafka Streaming**: Asynchronous publication of credit decisions
- **OpenAPI/Swagger Documentation**: Comprehensive API documentation via SpringDoc
- **OAuth2/OIDC Security**: JWT-based authentication with Spring Security
- **Distributed Task Scheduling**: ShedLock integration for distributed scheduled tasks
- **In-Memory Caching**: Caffeine cache for policies and configuration

## Prerequisites

- **Java 17** or higher
- **Maven 3.8+** (or use the included Maven Wrapper)
- **Docker & Docker Compose** (for local MongoDB)
- **Git**

## Environment Setup

### 1. Clone the Repository

```bash
git clone https://github.com/ATT-DP1/apm0045942-credit-routing-service.git
cd apm0045942-credit-routing-service
```

### 2. Verify Java Installation

```bash
javac -version
# Output should be: javac 17.x.x or higher
```

### 3. Start MongoDB Locally

From the project root, start MongoDB using Docker Compose:

```bash
docker-compose up -d
```

This starts a MongoDB instance that the service will connect to. Verify it's running:

```bash
docker-compose ps
```

To stop MongoDB later:

```bash
docker-compose down
```

## Building the Service

The project uses the **Maven Wrapper** (`./mvnw`), so you don't need Maven installed separately.

### 1. Clean and Compile

```bash
./mvnw clean compile
```

### 2. Build the Application

Build without running tests:

```bash
./mvnw package -DskipTests
```

Build with full test suite:

```bash
./mvnw clean package
```

### 3. Build an Executable JAR

```bash
./mvnw spring-boot:repackage
```

This creates an executable JAR at `target/routing-service-0.0.1-SNAPSHOT.jar`

### 4. Build a Container Image

```bash
./mvnw spring-boot:build-image
```

Creates an OCI-compliant container image for deployment.

## Running the Service

### Option 1: Maven Spring Boot Plugin (Development)

```bash
./mvnw spring-boot:run
```

The service will start and be available at `http://localhost:8080`

### Option 2: Run the Built JAR

```bash
java -jar target/routing-service-0.0.1-SNAPSHOT.jar
```

### Option 3: Docker Container

```bash
docker run -p 8080:8080 routing-service:latest
```

## Accessing the Service

Once the service is running:

### Swagger/OpenAPI Documentation

- **v1 API (Legacy)**: [http://localhost:8080/CreditCheck/v1/swagger-ui/index.html](http://localhost:8080/CreditCheck/v1/swagger-ui/index.html)
- **v2 API (Multi-Product)**: [http://localhost:8080/CreditCheck/v2/swagger-ui/index.html](http://localhost:8080/CreditCheck/v2/swagger-ui/index.html)

### Health Check

```bash
curl http://localhost:8080/actuator/health
```

### Available Metrics

```
http://localhost:8080/actuator/metrics
```

## Testing

The project uses **JUnit 5**, **Spock** (Groovy-based BDD), and **TestContainers** for MongoDB integration tests.

### Run All Tests

```bash
./mvnw test
```

### Run Integration Tests

```bash
./mvnw verify
```

### Run a Specific Test

```bash
./mvnw test -Dtest=CreditRoutingServiceTest
```

### Generate Code Coverage Report

```bash
./mvnw clean test jacoco:report
```

Coverage report is generated at: `target/site/jacoco/index.html`

## Code Quality & Formatting

### Apply Code Formatting

```bash
./mvnw spotless:apply
```

### Check Code Formatting

```bash
./mvnw spotless:check
```

## Project Structure

```
src/
├── main/
│   ├── java/com/att/creditcheck/
│   │   ├── CreditRoutingApplication.java          # Spring Boot entry point
│   │   ├── config/                                # Spring configuration (security, MongoDB)
│   │   ├── routing/                               # Routing logic (core domain)
│   │   ├── rules/                                 # DSL-based rules processor
│   │   ├── policy/                                # Credit policy enforcement
│   │   ├── creditcheckresult/                     # Credit check result models and services
│   │   ├── multiproduct/                          # Multi-product credit check handling
│   │   ├── oidc/                                  # OAuth2/OIDC integration
│   │   ├── csi/                                   # Credit Services Integration (SOAP clients)
│   │   ├── cache/                                 # Caffeine caching strategies
│   │   ├── audit/                                 # Audit logging
│   │   └── [other packages...]
│   └── resources/
│       ├── application.yml                        # Main configuration
│       ├── log4j2.xml                             # Logging configuration
│       └── wsdl/                                  # WSDL specifications for SOAP services
├── test/
│   ├── java/                                      # JUnit 5 tests
│   ├── groovy/                                    # Spock BDD tests
│   └── resources/                                 # Test fixtures and test configuration
└── helm/                                          # Kubernetes Helm charts
```

## Configuration

Configuration is managed via `src/main/resources/application.yml` with environment variable overrides:

### Key Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `MONGODB_DATABASE` | `routing_rules_local` | MongoDB database name |
| `MONGODB_USER_NAME` | `` | MongoDB username |
| `MONGODB_PASSWORD` | (required) | MongoDB password |
| `MONGODB_HOST` | `clear-dev-pl-1.3icpt.mongodb.net` | MongoDB host |
| `JWT_ISSUER_URI` | (required) | OAuth2 JWT issuer URI |
| `JWT_AUDIENCES` | (required) | Expected JWT audiences |
| `LOG_FILE_PATH` | `usr/logs/local` | Log output directory |
| `ROOT_LEVEL_LOG` | `INFO` | Root logging level |
| `APP_LEVEL_LOG` | `INFO` | Application logging level |
| `CORS_ALLOW_ORIGIN` | `https://clear.local.att.com:3000` | CORS allowed origins |

## Technology Stack

| Component | Version | Purpose |
|-----------|---------|---------|
| **Spring Boot** | 3.3.9 | Framework |
| **Java** | 17 | Language |
| **Spring Data MongoDB** | Latest | Data persistence |
| **Spring Security** | 6.x | Authentication & Authorization |
| **Spring Kafka** | Latest | Event streaming |
| **Spock** | 2.4 | BDD testing framework |
| **TestContainers** | Latest | Integration testing with MongoDB |
| **JaCoCo** | Latest | Code coverage |
| **Spotless** | Latest | Code formatting |
| **ShedLock** | 6.2.0 | Distributed task scheduling |
| **Caffeine** | 3.1.8 | In-memory caching |
| **MapStruct** | 1.5.3 | Bean mapping |

## Rules Processor

This project implements a custom **DSL-based Rules Processor** for flexible credit evaluation. The rules engine allows dynamic credit decision logic without code changes.

For detailed documentation, see: [Custom Rules Processor Wiki](https://wiki.web.att.com/display/CCABS/Custom+Rules+Processor)

## Continuous Integration

The project uses GitHub Actions for CI/CD. See `.github/workflows/maven.yml` for build and test automation.

## Pre-Commit Checklist

Before committing code:

1. Run the full build and tests:
   ```bash
   ./mvnw clean verify
   ```

2. Apply code formatting:
   ```bash
   ./mvnw spotless:apply
   ```

3. Review test coverage:
   ```bash
   ./mvnw jacoco:report
   ```

4. Follow Java 17/Groovy/Spock guidelines in `.github/instructions/Java.instructions.md`

## Documentation

- **[Copilot Instructions](.github/copilot-instructions.md)**: Comprehensive development guidelines
- **[Java/Groovy/Spock Guidelines](.github/instructions/Java.instructions.md)**: Coding standards
- **[JavaScript/MongoDB Guidelines](.github/instructions/javascript.instructions.md)**: Database script guidelines
- **[Helm Deployment](helm/)**: Kubernetes deployment configuration

## Troubleshooting

### MongoDB Connection Issues

Ensure MongoDB is running:
```bash
docker-compose ps
```

If not running, start it:
```bash
docker-compose up -d
```

### Build Failures

Clean and rebuild:
```bash
./mvnw clean verify
```

### Port Already in Use

If port 8080 is in use, specify a different port:
```bash
./mvnw spring-boot:run -Dspring-boot.run.arguments="--server.port=8081"
```

### Enable Debug Logging

Set the environment variable:
```bash
export APP_LEVEL_LOG=DEBUG
./mvnw spring-boot:run
```

Logs are written to `usr/logs/local/` by default.

## Contributing

Please ensure all code follows the guidelines in `.github/copilot-instructions.md` and `.github/instructions/Java.instructions.md` before submitting pull requests.

## Additional Resources

- **Service Health**: `http://localhost:8080/actuator/health`
- **Swagger UI v1**: `http://localhost:8080/CreditCheck/v1/swagger-ui/index.html`
- **Swagger UI v2**: `http://localhost:8080/CreditCheck/v2/swagger-ui/index.html`
- **MongoDB Database**: `routing_rules_local`
