---
description: 'Guidelines for building Credit Routing Service'
applyTo: '**/*.java'
---
# Copilot Coding Agent Onboarding Instructions

## Repository Overview

The **Credit Routing Service** is a Spring Boot 3.3.9 microservice that handles credit routing and orchestrating credit check requests based on configurable business rules managed by credit finance team. This service:

- Implements custom DSL-based rules processing for credit evaluation
- Integrates with MongoDB for persistent storage of routing rules and credit check results
- Provides REST APIs for credit check operations with OpenAPI/Swagger documentation
- Supports multi-product credit checks with identity verification
- Exposes Kafka event streaming for asynchronous credit decision publication
- Includes scheduled tasks using ShedLock for distributed locking in MongoDB
- Leverages Spring Security with OAuth2/OIDC for JWT-based authentication

## Build, Test, and Validation Instructions

### Environment Setup

Before building and running the service:

1. **Java 17**: Ensure you have Java 17 installed.
   ```bash
   javac -version
   ```

2. **Maven Wrapper**: The project includes Maven Wrapper (mvnw/mvnw.cmd). No separate Maven installation required.

3. **MongoDB**: The service requires a MongoDB instance. For local development:
   ```bash
   docker-compose up -d
   ```
   This starts a local MongoDB instance (see `docker-compose.yml`).

4. **Application Configuration**: The service reads configuration from `application.yml` in `src/main/resources/`. Key environment variables:
   - `MONGODB_DATABASE`: Database name 
   - `MONGODB_USER_NAME`, `MONGODB_PASSWORD`: MongoDB credentials
   - `MONGODB_HOST`: MongoDB connection host
   - `JWT_ISSUER_URI`: OAuth2 JWT issuer URI
   - `JWT_AUDIENCES`: Expected JWT audiences
   - `LOG_FILE_PATH`: Log output directory (default: `usr/logs/local`)
   - `ROOT_LEVEL_LOG`, `APP_LEVEL_LOG`: Logging levels (default: INFO)

### Build Steps

1. **Clean and compile** the project:
   ```bash
   ./mvnw clean compile
   ```

2. **Build a packaged JAR** (without running tests):
   ```bash
   ./mvnw package -DskipTests
   ```

3. **Build with full test suite**:
   ```bash
   ./mvnw clean package
   ```

4. **Build an executable Spring Boot JAR**:
   ```bash
   ./mvnw spring-boot:repackage
   ```

5. **Build a container image** (OCI-compliant):
   ```bash
   ./mvnw spring-boot:build-image
   ```

### Test Steps

The project uses a combination of **JUnit 5**, **Spock** (for Groovy behavior-driven tests), and **TestContainers** for MongoDB integration tests.

1. **Run all unit tests**:
   ```bash
   ./mvnw test
   ```

2. **Run unit tests only** (skip integration tests):
   ```bash
   ./mvnw test -Dgroups='!integration'
   ```

3. **Run integration tests only**:
   ```bash
   ./mvnw verify
   ```

4. **Run a specific test class**:
   ```bash
   ./mvnw test -Dtest=CreditRoutingServiceTest
   ```

5. **Run tests with code coverage report**:
   ```bash
   ./mvnw clean test jacoco:report
   ```
   Coverage report available at: `target/site/jacoco/index.html`

**Test Discovery**: The Maven Surefire plugin includes:
- `**/*Test.java` (JUnit tests)
- `**/*Spec.java` (Spock/Groovy tests)

**Integration Tests**: Maven Failsafe plugin discovers:
- `**/*IT.java` (Integration Tests)
- `**/*IntegrationTest.java` (Integration Test classes)

### Linting

The project uses **Spotless** for code formatting consistency. Apply formatting:
```bash
./mvnw spotless:apply
```

Check formatting without applying changes:
```bash
./mvnw spotless:check
```

**Code Quality**: Sonar exclusions are configured in `pom.xml` for auto-generated classes and models.

### Running the Service

1. **Run locally with Spring Boot Maven plugin**:
   ```bash
   ./mvnw spring-boot:run
   ```

2. **Run the built JAR**:
   ```bash
   java -jar target/routing-service-0.0.1-SNAPSHOT.jar
   ```

3. **Access Swagger UI** (after starting):
   ```
   http://localhost:8080/CreditCheck/v1/swagger-ui/index.html
   ```

4. **Health check endpoint**:
   ```
   http://localhost:8080/actuator/health
   ```

5. **Docker container**:
   ```bash
   docker run -p 8080:8080 routing-service:latest
   ```

The service runs on **port 8080** by default and uses a context path of `/CreditCheck`.

### Cleaning the Repository

1. **Clean build artifacts**:
   ```bash
   ./mvnw clean
   ```

2. **Deep clean** (includes removing Maven cache):
   ```bash
   ./mvnw clean -U
   ```

3. **Clean and verify the build**:
   ```bash
   ./mvnw clean verify
   ```

## Project Layout & Architecture

### Main Source Structure

```
src/main/java/com/att/creditcheck/
├── CreditRoutingApplication.java          # Spring Boot entry point
├── actuator/                              # Custom actuator endpoints
├── audit/                                 # Audit logging functionality
├── bcesfallout/                           # BCES fallout processing
├── cache/                                 # Caching strategies (Caffeine)
├── cas/                                   # CAS (Centralized Authentication Service) integration
├── ccresultmonitoring/                    # Credit check result monitoring
├── common/                                # Common utilities and helpers
├── config/                                # Spring configuration (security, MongoDB, etc.)
├── configuration/                         # Application configuration properties
├── creditcheckresult/                     # Credit check result models and services
├── csi/                                   # CSI (Credit Services Integration) - SOAP clients
├── customeraccounttype/                   # Customer account type logic
├── eiplimit/                              # EIP (Equipment Installment Plan) limit processing
├── exceptions/                            # Custom exception classes (excluded from coverage)
├── iebus/                                 # IE Bus integration
├── logging/                               # Custom logging configuration
├── mock/                                  # Mock service implementations for testing
├── multiproduct/                          # Multi-product credit check handling
├── oidc/                                  # OIDC (OAuth2) authentication integration
├── policy/                                # Credit policy enforcement
├── preapproval/                           # Pre-approval logic
├── productmapping/                        # Product mapping services
├── productpolicy/                         # Product-specific policies
├── roleassignment/                        # Role-based access control
├── roles/                                 # Role definitions
├── routing/                               # Routing logic (core domain)
├── rules/                                 # Custom DSL-based rules processor
├── saartsegment/                          # SAARТ segment handling
├── ubct/                                  # UBCT (User Business Credit Type) processing
└── util/                                  # Utility classes (excluded from coverage)
```

### Configuration Files

- **`application.yml`** (`src/main/resources/`): Main Spring Boot configuration with:
  - SpringDoc OpenAPI grouping (multiple API endpoints groups)
  - CORS settings
  - Logging configuration
  - MongoDB connection settings
  - JWT/OAuth2 security configuration
  - Retry policies

- **`application.properties`** (root): Basic property overrides

- **`log4j2.xml`** (`src/main/resources/`): Log4j2 configuration with rolling file appenders

- **`pom.xml`** (root): Maven build configuration with:
  - Spring Boot 3.3.9 parent
  - Key dependencies: Spring Data MongoDB, Spring Security, Spock, TestContainers, Kafka
  - Plugins: Maven Compiler, Surefire, Failsafe, JaCoCo, Spotless, Gmavenplus (for Groovy)

### Validation Pipelines

- **Unit Tests**: JUnit 5 tests (`**/*Test.java`)
- **Spock/BDD Tests**: Behavior-driven tests (`**/*Spec.java`)
- **Integration Tests**: TestContainers-based MongoDB tests (`**/*IT.java`, `**/*IntegrationTest.java`)
- **Code Coverage**: JaCoCo reports (target: typically >80% for non-excluded classes)
- **Formatting**: Spotless ensures code consistency
- **SonarQube**: Coverage and quality exclusions configured for generated code and DTOs

### Check-in Requirements

Before committing code:

1. **Run full build and tests**:
   ```bash
   ./mvnw clean verify
   ```

2. **Apply code formatting**:
   ```bash
   ./mvnw spotless:apply
   ```

3. **Verify no compilation errors**:
   ```bash
   ./mvnw clean compile
   ```

4. **Review test coverage**:
   ```bash
   ./mvnw jacoco:report
   ```
   Check `target/site/jacoco/index.html` for coverage metrics.

5. **Ensure code follows Java 17 + Groovy/Spock guidelines** (see `.github/instructions/Java.instructions.md`)

## Key Files in Repo Root

- **`pom.xml`**: Maven configuration for all dependencies and build plugins
- **`mvnw` / `mvnw.cmd`**: Maven Wrapper scripts (use `./mvnw` instead of `mvn`)
- **`README.md`**: Quick start guide and high-level project overview
- **`docker-compose.yml`**: Local MongoDB setup for development
- **`Dockerfile`**: Container image definition for the microservice
- **`application.properties`**: Legacy property overrides (primarily use `application.yml`)
- **`.github/instructions/Java.instructions.md`**: Java 17/Groovy/Spock coding standards
- **`.github/instructions/javascript.instructions.md`**: MongoDB aggregation script guidelines
- **`helm/`**: Kubernetes Helm charts for deployment (values for dev, stage, test, prod)
- **`scripts/`**: Database migration scripts organized by version (v3.0.0, v4.0.0, v5.0.0, v6.0.0)
- **`settings/`**: Environment-specific application settings (dev, stage, test, prod)
- **`certs/`**: SSL/TLS certificate files for HTTPS communication
- **`sentry/`**: Sentry integration configuration and error tracking

## Agent Guidance

### When Modifying Java Code

1. **Follow Java 17 idioms**: Use records, switch expressions, Stream.toList(), var where appropriate (see Java.instructions.md)
2. **Immutability first**: Prefer `record` for data carriers, use `List.of()` for small constants
3. **Logging**: Use SLF4J with parameterized messages (no string concatenation in logs)
4. **Exception handling**: Create domain-specific exceptions, wrap with context when rethrowing
5. **Spring patterns**: Leverage dependency injection, use `@Service`, `@Repository`, `@Configuration`
6. **Testing**: Write Spock tests for behavior validation; use TestContainers for MongoDB integration tests
7. **Null safety**: Avoid returning null from public APIs; use `Optional` or empty collections
8. **Code formatting**: Always run `./mvnw spotless:apply` before committing

### When Adding New Features

1. **Routing logic**: Add new routing strategies in `routing/` package
2. **Rules processing**: Extend DSL-based rules processor in `rules/` package
3. **API endpoints**: Create controller classes, document with OpenAPI annotations
4. **MongoDB operations**: Use Spring Data MongoDB repository interfaces, add indexes as needed
5. **Configuration**: Add properties to `application.yml` with environment variable overrides
6. **Database migrations**: Create MongoDB aggregation scripts in `scripts/v<version>/` directory

### When Debugging

- **Enable debug logging**: Set `APP_LEVEL_LOG=DEBUG` in environment
- **Check logs**: Logs are written to `usr/logs/local/` by default
- **Use Spring Boot Actuator**: Health checks and metrics at `http://localhost:8080/actuator/`
- **Test with mock data**: Use `mock/` package implementations for isolated testing
- **MongoDB inspection**: Connect directly to MongoDB and query `routing_rules_mt5401_local` database

## Additional Notes

- **ShedLock**: Distributed task scheduling uses ShedLock with MongoDB provider. Scheduled tasks are locked to prevent concurrent execution across instances.
- **Kafka Integration**: The service publishes credit decisions to Kafka topics for downstream consumption.
- **Caching**: Uses Caffeine cache library for in-memory caching of policies and configuration.
- **WSDL Integration**: CSI microservice integration via SOAP/WSDL clients (auto-generated from WSDL specifications in `src/main/resources/wsdl/`)
- **Security**: OAuth2/OIDC with JWT tokens; Spring Security configured for role-based access control.
- **OpenAPI**: Multiple API groups documented via SpringDoc (v1 legacy, v2 multi-product, admin endpoints)

## Useful Commands

| Task                        | Maven Command                      | Description                               |
| :-------------------------- | :--------------------------------- | :---------------------------------------- |
| Run the application         | `./mvnw spring-boot:run`         | Starts the Spring Boot app locally.       |
| Build the application       | `./mvnw package`                 | Produces the application JAR/WAR.         |
| Run tests                   | `./mvnw test`                    | Executes the unit test suite.             |
| Run integration tests       | `./mvnw verify`                  | Executes integration tests with Failsafe. |
| Repackage as executable JAR | `./mvnw spring-boot:repackage`   | Builds an executable Spring Boot JAR.     |
| Build a container image     | `./mvnw spring-boot:build-image` | Creates an OCI-compliant container image. |
| Apply code formatting       | `./mvnw spotless:apply`          | Applies Spotless formatting rules.        |
| Check code formatting       | `./mvnw spotless:check`          | Verifies code matches Spotless rules.     |
| Generate coverage report    | `./mvnw jacoco:report`           | Creates JaCoCo coverage report.           |
| Clean build artifacts       | `./mvnw clean`                   | Removes target directory and build files. |
| Full verify pipeline        | `./mvnw clean verify`            | Cleans, builds, tests, and verifies.      |
