#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

DOCKER_REPO_USERNAME="mt5401@intl.att.com"
DOCKER_REPO_ACCESS_TOKEN="cmVmdGtuOjAxOjE4MDEwNDA2Mzc6OVEwdVlMdDlFMk5PYjEwUVFzRFZickh4NnZJ"

JAVA_HOME="$(/usr/libexec/java_home -v 17 2>/dev/null || true)"
if [[ -z "$JAVA_HOME" ]]; then
    echo "Java 17 not found"
    exit 1
fi
export JAVA_HOME
export PATH="$JAVA_HOME/bin:$PATH"

if ! command -v mvn >/dev/null 2>&1; then
    echo "mvn not found"
    exit 1
fi

echo "Using JAVA_HOME=$JAVA_HOME"
java -version
mvn -version

MVN="mvn"
MVN_SETTINGS=""

if [[ -n "${DOCKER_REPO_USERNAME:-}" && -n "${DOCKER_REPO_ACCESS_TOKEN:-}" ]]; then
    MVN_SETTINGS="-s $SCRIPT_DIR/settings.xml"
fi

rm -rf target/generated-sources/csi
rm -rf target/classes
rm -rf target/test-classes

echo "Building jar..."
echo "with MVN settings $MVN_SETTINGS"
echo "with MVN command $MVN"
$MVN -Dspotless.skip=true -Dmaven.test.skip=true package $MVN_SETTINGS

APP_JAR="$SCRIPT_DIR/target/routing-service-0.0.1-SNAPSHOT.jar"

if [[ ! -f "$APP_JAR" ]]; then
    echo "jar not found: $APP_JAR"
    exit 1
fi

echo "Starting app..."

exec java -jar "$APP_JAR"
