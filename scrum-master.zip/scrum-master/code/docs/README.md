# docs

The canonical specs, decisions, and plans for this agent live in the project home one
level up, **`../../`** (this `code/` folder's parent):

- `../../Scrum_Master_Agent_PRD.md` — the anchor spec
- `../../design/Architecture.md` — components, stack, Jira integration, data model
- `../../design/adr/0001-langgraph-orchestration.md` — why LangGraph
- `../../planning/Roadmap.md` — P0 → P3, each gated
- `../../tracking/Status.md` — live status (open each session)

This `code/` folder is the **code**; its parent `scrum-master/` is the **brain**. The
brain holds the docs, `code/` holds the implementation — link across, don't duplicate.
