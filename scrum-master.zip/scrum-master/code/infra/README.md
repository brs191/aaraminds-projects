# Infra

Terraform (AzureRM, RBAC mode) for deploying to the AaraMinds fixed stack. **Stub** —
the topology is documented and the provider/resource-group scaffold compiles, but the
PostgreSQL / Key Vault / Container Apps resources are TODOs to fill in during P0–P1.

Target topology: see `../../design/Architecture.md`.

Auth model: GitHub Actions with OIDC (no long-lived cloud creds). Remote state in an
`azurerm` backend — configure before first `apply`.
